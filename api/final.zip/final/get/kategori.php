<?php
	include "../koneksi.php";
	$res = array();
	$data = $con->query("SELECT * FROM tb_kategori");
	foreach ($data as $a) {
		$res[] = array(
			'id_kategori' => $a['id_kategori'],
			'kategori' => $a['kategori']
		);
	}

	echo json_encode($res);
?>