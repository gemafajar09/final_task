<?php
	include "../koneksi.php";
	$id = $_GET['id'];
	$res = array();
	if($id == 0)
	{
		$data = $con->query("SELECT * FROM tb_buku a LEFT JOIN tb_kategori b ON a.id_kategori=b.id_kategori");
	}else{
		$data = $con->query("SELECT * FROM tb_buku a LEFT JOIN tb_kategori b ON a.id_kategori=b.id_kategori WHERE a.id_kategori='$id'");
	}
	foreach ($data as $a) {
		$res[] = array(
			'id_buku' => $a['id_buku'],
			'kategori' => $a['kategori'],
			'foto' => $url."buku/".$a['foto'],
			'judul' => $a['judul'],
			'deskripsi' => $a['deskripsi'],
			'penerbit' => $a['penerbit']
		);
	}

	echo json_encode($res);
?>