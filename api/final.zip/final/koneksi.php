<?php
$url = 'http://192.168.1.5/final/';

$con = new mysqli('localhost','root','','db_final');