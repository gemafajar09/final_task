<?php
	include "koneksi.php";
	$res = array();
	$data = $con->query("SELECT * FROM tb_slider");
	foreach ($data as $a) {
		$res[] = array(
			'id_slider' => $a['id_slider'],
			'gambar' => $url."slider/".$a['gambar']
		);
	}

	echo json_encode($res);
?>