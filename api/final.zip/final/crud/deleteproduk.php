<?php
	include "../koneksi.php";
	$id = $_GET['id'];
	$cek = $con->query("SELECT * FROM tb_produk WHERE id_produk='$id'")->fetch_assoc();
	if($cek != '')
	{
		unlink('../'.$cek['foto']);
	}

	$data = $con->query("DELETE FROM tb_produk WHERE id_produk='$id'");
	if($data == TRUE)
	{
		$msg = array('pesan' => 'Success');
	}else{
		$msg = array('pesan' => 'Error');
	}

	echo json_encode($msg);
?>