<?php
	include "../koneksi.php";
	$msg = array();
	$id_kategori = $_POST['id'];
	$kategori = $_POST['kategori'];
	if($id_kategori == '')
	{
		$data = $con->query("INSERT INTO tbl_kategori (kategori) VALUES ('$kategori')");
	}else{
		$data = $con->query("UPDATE tbl_kategori SET kategori='$kategori' WHERE id_kategori='$id_kategori'");
	}

	if($data == TRUE)
	{
		$msg = array('pesan' => 'Success');
	}else{
		$msg = array('pesan' => 'Error');
	}
	echo json_encode($msg);
?>