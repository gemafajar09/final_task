<?php
include "../koneksi.php";

	$res = array();
	$id = $_POST['id'];
	if($id == '')
	{
		$nama_file = $_POST['filename'];	
		if($nama_file != '')
		{
			$image = $_POST['image'];
			$image_asli = base64_decode($image);
			$file = file_put_contents($nama_file, $image_asli);
		}else{
			$file = '';
		}

		$nama = $_POST['nama'];
		$jumlah = $_POST['jumlah'];
		$harga = $_POST['harga'];
		$kategori = $_POST['kategori'];
		$data = $con->query("INSERT INTO `tb_produk`(`nama`, `jumlah`, `kategori`, `foto`,`harga`) VALUES ('$nama','$jumlah','$kategori','$nama_file','$harga')");
	}else{
		$nama_file = $_POST['filename'];	
		$nama = $_POST['nama'];
		$jumlah = $_POST['jumlah'];
		$harga = $_POST['harga'];
		$kategori = $_POST['kategori'];
		if($nama_file != '')
		{
			$image = $_POST['image'];
			$image_asli = base64_decode($image);
			$file = file_put_contents($nama_file, $image_asli);
			$data = $con->query("UPDATE `tb_produk` SET `nama`='$nama', `jumlah`='$jumlah', `kategori`='$kategori', `foto`='$nama_file',`harga`='$harga' WHERE id_produk='$id'");
		}else{
			$data = $con->query("UPDATE `tb_produk` SET `nama`='$nama', `jumlah`='$jumlah', `kategori`='$kategori',`harga`='$harga' WHERE id_produk='$id'");
		}
		
	}

	if($data == TRUE)
	{
		$res = array('pesan' => 'Success');
	}else{
		$res = array('pesan' => 'Error');
	}
	echo json_encode($res);