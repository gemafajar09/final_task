<?php
	include "../koneksi.php";
	$res = array();
	$data = $con->query("SELECT * FROM tbl_kategori");
	foreach ($data as $a) {
		$res[] = array(
			'id_kate' => $a['id_kategori'],
			'kate' => $a['kategori']
		);
	}

	echo json_encode($res);
?>