<?php
	include "../koneksi.php";
	$id = $_GET['id'];
	$data = $con->query("DELETE FROM tbl_kategori WHERE id_kategori='$id'");
	if($data == TRUE)
	{
		$msg = array('pesan' => 'Success');
	}else{
		$msg = array('pesan' => 'Error');
	}

	echo json_encode($msg);
?>