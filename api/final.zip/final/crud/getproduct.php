<?php
	include "../koneksi.php";
	$kategori = $_GET['kategori'];
	$res = array();
	if($kategori == 'All')
	{
		$data = $con->query("SELECT * FROM tb_produk a LEFT JOIN tbl_kategori b ON a.kategori=b.kategori");
	}else{
		$data = $con->query("SELECT * FROM tb_produk a LEFT JOIN tbl_kategori b ON a.kategori=b.kategori WHERE a.kategori='$kategori'");
	}
	foreach ($data as $a) {
		$foto = $a['foto'] != '' ? $a['foto'] : 'noimage.png';
		$res[] = array(
			'id_produk' => $a['id_produk'],
			'nama' => $a['nama'],
			'foto' => $url.$foto,
			'jumlah' => $a['jumlah'],
			'kategori' => $a['kategori'],
			'harga' => $a['harga']
		);
	}

	echo json_encode($res);
?>