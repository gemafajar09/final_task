<?php
	include "../koneksi.php";
	$id = $_GET['id'];
	$data = $con->query("DELETE FROM tb_keranjang WHERE id_keranjang='$id'");
	if($data == TRUE)
	{
		$msg = array('pesan' => 'Success');
	}else{
		$msg = array('pesan' => 'Error');
	}

	echo json_encode($msg);
?>