<?php
	include "../koneksi.php";
	$id_user = $_GET['id_user'];
	$res = array();

		$data = $con->query("SELECT a.id_keranjang, a.tanggal, a.jumlah as jumlahs, b.*, c.kategori as kategoris FROM tb_keranjang a LEFT JOIN tb_produk b ON a.id_produk=b.id_produk LEFT JOIN tbl_kategori c ON b.kategori=c.kategori WHERE a.id_user='$id_user'");
		$total;
	foreach ($data as $a) {
		$total = $a['harga']*$a['jumlahs'];
		$foto = $a['foto'] != '' ? $a['foto'] : 'noimage.png';
		$res[] = array(
			'id_keranjang' => $a['id_keranjang'],
			'id_produk' => $a['id_produk'],
			'nama' => $a['nama'],
			'foto' => $url.$foto,
			'jumlah' => $a['jumlahs'],
			'kategori' => $a['kategoris'],
			'harga' => $a['harga'],
			'tanggal' => $a['tanggal'],
			'total' => $total
		);
	}

	echo json_encode($res);
?>