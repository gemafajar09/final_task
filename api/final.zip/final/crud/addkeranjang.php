<?php
	include "../koneksi.php";
	$msg = array();
	$id_keranjang = $_POST['id_keranjang'];
	if($id_keranjang == '')
	{
		$id_produk = $_POST['id_produk'];
		$jumlah = $_POST['jumlah'];
		$id_user = $_POST['id_user'];
		$tanggal = date('Y-m-d');
		$data = $con->query("INSERT INTO `tb_keranjang`(`id_user`, `id_produk`, `tanggal`, `jumlah`) VALUES ('$id_user','$id_produk','$tanggal','$jumlah')");
	}else{
			$cek = $con->query("SELECT * FROM tb_keranjang WHERE id_keranjang='$id_keranjang'")->fetch_assoc();	
		if($_POST['action'] == 'sum')
		{
			$jumlah1 = $cek['jumlah'] + 1;
			$data = $con->query("UPDATE tb_keranjang SET jumlah='$jumlah1' WHERE id_keranjang='$id_keranjang'");
		}else{
			$jumlah1 = $cek['jumlah'] - 1;
			$data = $con->query("UPDATE tb_keranjang SET jumlah='$jumlah1' WHERE id_keranjang='$id_keranjang'");
		}
		
	}

	if($data == TRUE)
	{
		$msg = array('pesan' => 'Success');
	}else{
		$msg = array('pesan' => 'Error');
	}
	echo json_encode($msg);
?>