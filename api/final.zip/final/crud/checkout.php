<?php
	include "../koneksi.php";
	$id_user = $_POST['id'];
	$cek = $con->query("SELECT * FROM tb_keranjang WHERE id_user='$id_user'");
	foreach($cek as $i => $a){
		$con->query("INSERT INTO `tb_checkout`(`id_user`, `id_produk`, `tanggal`, `jumlah`) VALUES ('$a[id_user]','$a[id_produk]','$a[tanggal]','$a[jumlah]')");
		// kurangi stok
		$stok = $con->query("SELECT * FROM tb_produk WHERE id_produk='$a[id_produk]'")->fetch_assoc();
		$hasil = $stok['jumlah'] - $a['jumlah'];
		$update = $con->query("UPDATE tb_produk SET jumlah='$hasil' WHERE id_produk='$a[id_produk]'");
		$con->query("DELETE FROM tb_keranjang WHERE id_user='$id_user'");
	}

	echo json_encode(['pesan' => 'Success']);